# Unuseful file
The only purpose of this file is to keep the folder *Output* in the repository