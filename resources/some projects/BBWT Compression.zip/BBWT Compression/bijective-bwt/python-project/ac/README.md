# Arithmetic coding 
C++ implementation of arithmetic coding algorithm based on algorithm proposed in article: Arithmetic Coding for Data Compression by Ian H. Witten, Radford M. Neal, John G. Cleary (1987).Communications of the ACM. Volume 30. Number 6. 520-540pp.
