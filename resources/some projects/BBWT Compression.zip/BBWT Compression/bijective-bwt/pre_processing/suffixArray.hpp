#include <vector>
#include <string>

using namespace std;

vector <int> suffix_array_manber_myers(const string &str);