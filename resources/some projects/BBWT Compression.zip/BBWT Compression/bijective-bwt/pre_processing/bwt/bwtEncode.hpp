#include <string>

const int TERMINATOR = -1;

using namespace std;

string bwtEncode(const string str);