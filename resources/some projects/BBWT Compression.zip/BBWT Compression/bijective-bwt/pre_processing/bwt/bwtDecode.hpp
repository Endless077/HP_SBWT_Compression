#include <vector>
#include <string>

using namespace std;

string bwtDecode(string str);