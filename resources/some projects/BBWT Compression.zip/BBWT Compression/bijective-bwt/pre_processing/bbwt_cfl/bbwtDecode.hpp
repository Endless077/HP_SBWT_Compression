#include <iostream>
#include <string>
#include <vector>

std::string bbwtDecode(const std::string &data);