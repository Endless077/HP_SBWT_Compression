#include <vector>
#include <string>

using namespace std;

vector<string> cfl(string str);