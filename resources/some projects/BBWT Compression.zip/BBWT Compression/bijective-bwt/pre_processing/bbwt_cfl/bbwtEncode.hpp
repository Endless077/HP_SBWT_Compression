#include <string>

using namespace std;

struct Rotation{
    int w;
    int r;
};

string bbwtEncode(const string str);